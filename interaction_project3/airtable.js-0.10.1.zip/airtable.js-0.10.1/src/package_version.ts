// This will become package_version_browser.js when doing a browser build.
// See <https://github.com/Airtable/airtable.js/pull/132> for more.
export = require('../package.json').version;
