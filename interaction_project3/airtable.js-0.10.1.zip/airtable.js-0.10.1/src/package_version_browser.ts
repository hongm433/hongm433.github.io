export = process.env.npm_package_version;
