/**
 * Given a function fn that takes a callback as its last argument, returns
 * a new version of the function that takes the callback optionally. If
 * the function is not called with a callback for the last argument, the
 * function will return a promise instead.
 */
function callbackToPromise(fn, context, callbackArgIndex = void 0): any {
    return function() {
        let thisCallbackArgIndex;
        if (callbackArgIndex === void 0) {
            // istanbul ignore next
            thisCallbackArgIndex = arguments.length > 0 ? arguments.length - 1 : 0;
        } else {
            thisCallbackArgIndex = callbackArgIndex;
        }
        const callbackArg = arguments[thisCallbackArgIndex];
        if (typeof callbackArg === 'function') {
            fn.apply(context, arguments);
            return void 0;
        } else {
            const args = [];
            // If an explicit callbackArgIndex is set, but the function is called
            // with too few arguments, we want to push undefined onto args so that
            // our constructed callback ends up at the right index.
            const argLen = Math.max(arguments.length, thisCallbackArgIndex);
            for (let i = 0; i < argLen; i++) {
                args.push(arguments[i]);
            }
            return new Promise((resolve, reject) => {
                args.push((err, result) => {
                    if (err) {
                        reject(err);
                    } else {
                        resolve(result);
                    }
                });
                fn.apply(context, args);
            });
        }
    };
}

export = callbackToPromise;
